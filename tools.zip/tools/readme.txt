 

新增/修改路由：
    url ：http://172.26.83.53:18888/route/insertOrUpdate
    method：post
    header： Content-Type application/json
    body：路由的json串，新增的话id为空。例如：{"name":"r2","path":"p1","pid":3,"template":"","parent":false,"generate":true,"isParent":false,"isGenerate":true,"username":"abc"}

删除路由：
   url: http://172.26.83.53:18888/route/delete
   method：post
   header： Content-Type application/json
   body：待删除id的json串，新增的话id为空。例如：{"id":15}

获取单个路由：
  url：http://172.26.83.53:18888/route/{id} ,例如http://172.26.83.53:18888/route/1
  method：get

获取某用户所有路由：
  url：http://172.26.83.53:18888/route/getAll/{username},例如http://172.26.83.53:18888/route/getAll/yunli
  method：get


   
