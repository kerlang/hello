CREATE TABLE `yl_route`
(
  `id`                      BIGINT(20) UNSIGNED                                    NOT NULL AUTO_INCREMENT COMMENT '路由标识',
  `name`                    VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  DEFAULT '' COMMENT '路由名称',
  `path`                    VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '路由路径',
  `pid`                     BIGINT(20) UNSIGNED COMMENT '父级路由',
  `parent`                tinyint(1)                                           DEFAULT 0 COMMENT '是否为父容器',
  `template`                int COMMENT '模板',
  `generate`              tinyint(1)  COMMENT '是否生成',
  `username`                VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  DEFAULT '' COMMENT '用户名称',
  PRIMARY KEY (`id`)
) ENGINE = INNODB
  DEFAULT CHARSET = utf8mb4 COMMENT ='路由表';
