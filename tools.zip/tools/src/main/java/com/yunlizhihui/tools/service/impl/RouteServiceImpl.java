package com.yunlizhihui.tools.service.impl;

import com.yunlizhihui.tools.dao.YlRouteDao;
import com.yunlizhihui.tools.entity.YlRouteEntity;
import com.yunlizhihui.tools.model.vo.RouteVo;
import com.yunlizhihui.tools.service.RouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class RouteServiceImpl implements RouteService {

    @Resource
    private YlRouteDao ylRouteDao;

    @Override
    public RouteVo insertOrUpdate(RouteVo routeVo) {
        YlRouteEntity entity = routeVo.converToEntity();
        if(entity.getId() == null){
            ylRouteDao.insert(entity);
        }else{
            ylRouteDao.updateById(entity);
        }
        routeVo.convertFromEntity(entity);
        return routeVo;
    }

    @Override
    public void deleteRoute(Long id) {
        ylRouteDao.deleteById(id);
    }

    @Override
    public RouteVo getRoute(Long id) {
        RouteVo vo = new RouteVo();
        try {
            YlRouteEntity entity = ylRouteDao.selectById(id);
            vo.convertFromEntity(entity);
        }catch(Exception e){
            e.printStackTrace();
        }
        return vo;
    }

    @Override
    public List<RouteVo> getRouteList(String username) {
        List<RouteVo> ret = new ArrayList<RouteVo>();
        List<YlRouteEntity> firstLevel = ylRouteDao.getRootChildren(username);
        for(YlRouteEntity entity : firstLevel){
            RouteVo r = new RouteVo();
            r.convertFromEntity(entity);
            ret.add(r);
            fillSubList(r);
        }
        return ret;
    }

    private void fillSubList(RouteVo r){
        List<YlRouteEntity> sub = ylRouteDao.getSubList(r.getId());
        for(YlRouteEntity entity : sub){
            RouteVo v = new RouteVo();
            v.convertFromEntity(entity);
            fillSubList(v);
            r.getChildren().add(v);
        }
    }
}
