package com.yunlizhihui.tools.model.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.yunlizhihui.tools.entity.YlRouteEntity;

import java.util.ArrayList;
import java.util.List;

//@JsonInclude(JsonInclude.Include.NON_NULL)
public class RouteVo {
    private Long id;

    private String name;

    private String path;

    private Long pid;

    @JsonProperty("isParent")
    private boolean isParent;

    private Long template;

    @JsonProperty("isGenerate")
    private boolean isGenerate;

    @JsonProperty("username")
    private String username;

    private List<RouteVo> children = new ArrayList<RouteVo>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    @JsonIgnore
    public boolean isParent() {
        return isParent;
    }

    public void setParent(boolean parent) {
        isParent = parent;
    }

    public Long getTemplate() {
        return template;
    }

    public void setTemplate(Long template) {
        this.template = template;
    }

    @JsonIgnore
    public boolean isGenerate() {
        return isGenerate;
    }

    public void setGenerate(boolean generate) {
        isGenerate = generate;
    }

    public List<RouteVo> getChildren() {
        return children;
    }

    public void setChildren(List<RouteVo> children) {
        this.children = children;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void convertFromEntity(YlRouteEntity entity){
        this.id = entity.getId();
        this.name = entity.getName();
        this.path = entity.getPath();
        this.pid = entity.getPid();
        this.isParent = entity.isParent();
        this.template = entity.getTemplate();
        this.isGenerate = entity.isGenerate();
        this.username = entity.getUsername();
    }

    public YlRouteEntity converToEntity(){
        YlRouteEntity entity = new YlRouteEntity();
        entity.setId(this.getId());
        entity.setName(this.getName());
        entity.setPath(this.getPath());
        entity.setPid(this.getPid());
        entity.setParent(this.isParent);
        entity.setTemplate(this.getTemplate());
        entity.setGenerate(this.isGenerate());
        entity.setUsername(this.getUsername());
        return entity;
    }
}
