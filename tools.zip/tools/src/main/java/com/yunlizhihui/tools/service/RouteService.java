package com.yunlizhihui.tools.service;

import com.yunlizhihui.tools.model.vo.RouteVo;

import java.util.List;

public interface RouteService {

    public RouteVo insertOrUpdate(RouteVo routeVo);
    public void deleteRoute(Long id);
    public RouteVo getRoute(Long id);
    public List<RouteVo> getRouteList(String username);


}


