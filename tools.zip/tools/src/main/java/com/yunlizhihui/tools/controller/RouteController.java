package com.yunlizhihui.tools.controller;


import com.yunlizhihui.tools.model.vo.RouteVo;
import com.yunlizhihui.tools.service.RouteService;
import com.yunlizhihui.tools.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import com.yunlizhihui.tools.model.qo.RouteQo;

import java.util.List;

@RestController
public class RouteController {

    @Autowired
    private RouteService routeService;


    @PostMapping("/route/insertOrUpdate")
    public Object insertOrUpdate(@RequestBody RouteVo routeVo) {
        RouteVo result = routeService.insertOrUpdate(routeVo);
        return Result.ok(result);
    }


    @PostMapping("/route/delete")
    public Object deleteApp(@RequestBody RouteQo routeQo) {
        routeService.deleteRoute(routeQo.getId());
        return Result.ok();
    }

    @GetMapping("/route/{id}")
    public RouteVo getRoute(@PathVariable("id")Long id){
        RouteVo r = routeService.getRoute(id);
        return r;
    }

    @GetMapping("/route/getAll/{username}")
    public List<RouteVo> getAll(@PathVariable("username")String username){
        return routeService.getRouteList(username);
    }
}
