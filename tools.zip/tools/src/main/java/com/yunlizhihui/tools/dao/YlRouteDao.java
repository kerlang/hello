package com.yunlizhihui.tools.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yunlizhihui.tools.entity.YlRouteEntity;

import java.util.List;


public interface YlRouteDao extends BaseMapper<YlRouteEntity> {

    List<YlRouteEntity> getRootChildren(String username);
    List<YlRouteEntity> getSubList(Long id);

}
